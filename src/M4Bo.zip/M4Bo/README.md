# M4Bo

Es un proyecto de software gratuito creado para la gestion de almacenes, puede ser utilizado por cualquier entidad  en caso de adaptarse al producto y el uso del mismo no involucra un pago de licencia.

<mark>El Proyecto estará disponible el 30-01-2019</mark>

## Sugerencias y Colaboraciones
email : alanwalter45@gmail.com

> copyright@2019
<a href="http://alanwalter45@gmail.com" target="_blank">
 @alanwalter45
 </a>