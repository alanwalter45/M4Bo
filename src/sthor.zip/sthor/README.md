# PROYECTO STHOR

## STHOR

Es un proyecto de software gratuito creado para la gestion de almacenes, puede ser utilizado por cualquier entidad  en caso de adaptarse al producto y el uso del mismo no involucra un pago de licencia.

<mark>El Proyecto se encuentra en construccion...</mark>

## Sugerencias y Colaboraciones
canal en discord : https://discord.gg/AaNK56A
<br>
email : alanwalter45@gmail.com

> copyright@2019
<a href="http://alanwalter45@gmail.com" target="_blank">
 @alanwalter45
 </a>